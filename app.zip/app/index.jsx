import React, { useState } from "react";
import { View, FlatList, StyleSheet } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { TextInput, Button, Card, Text, IconButton } from "react-native-paper";
import { data } from "@/data/to_do";

export default function Index() {
  const [todos, setTodos] = useState(data.sort((a, b) => b.id - a.id));
  const [text, setText] = useState('');

  const addTodo = () => {
    if (text.trim()) {
      const newId = todos.length > 0 ? Math.max(...todos.map(todo => todo.id)) + 1 : 1;
      setTodos([{ id: newId, titulo: text, completo: false }, ...todos]);
      setText('');
    }
  };

  const toggleTodo = (id) => {
    setTodos(todos.map(todo => 
      todo.id === id ? { ...todo, completo: !todo.completo } : todo
    ));
  };

  const removeTodo = (id) => {
    setTodos(todos.filter(todo => todo.id !== id));
  };

  const renderItem = ({ item }) => (
    <Card style={styles.todoItem} mode="elevated">
      <Card.Content>
        <Text 
          style={[styles.todoText, item.completo && styles.completedText]}
          onPress={() => toggleTodo(item.id)}
        >
          {item.titulo}
        </Text>
      </Card.Content>
      <IconButton 
        icon="delete"
        iconColor="red"
        size={24}
        onPress={() => removeTodo(item.id)}
      />
    </Card>
  );

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.inputContainer}>
        <TextInput
          style={styles.input}
          mode="outlined"
          label="Nova Tarefa"
          value={text}
          onChangeText={setText}
        />
        <Button mode="contained" onPress={addTodo} style={styles.addButton}>
          Adicionar
        </Button>
      </View>
      <FlatList
        data={todos}
        renderItem={renderItem}
        keyExtractor={todo => String(todo.id)}
        contentContainerStyle={{ flexGrow: 1 }}
        showsVerticalScrollIndicator={false}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#121212', // Preto fosco estilo Material Design
    padding: 16,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  input: {
    flex: 1,
    marginRight: 10,
  },
  addButton: {
    borderRadius: 5,
  },
  todoItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 10,
    padding: 10,
    backgroundColor: "#1E1E1E", // Cinza escuro
  },
  todoText: {
    fontSize: 18,
    color: 'white',
  },
  completedText: {
    textDecorationLine: 'line-through',
    color: 'gray',
  },
});
