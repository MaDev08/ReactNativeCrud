
export const data = [
    { id: 1, titulo: "Estudar JavaScript", completo: false },
    { id: 2, titulo: "Criar estrutura da To-Do List", completo: true },
    { id: 3, titulo: "Adicionar funcionalidade de adicionar tarefas", completo: false },
    { id: 4, titulo: "Implementar remoção de tarefas", completo: false },
    { id: 5, titulo: "Marcar tarefas como completas", completo: false },
    { id: 6, titulo: "Estilizar a To-Do List", completo: false },
    { id: 7, titulo: "Salvar tarefas no LocalStorage", completo: false },
    { id: 8, titulo: "Criar versão responsiva", completo: false },
    { id: 9, titulo: "Adicionar filtros para tarefas", completo: false },
    { id: 10, titulo: "Melhorar experiência do usuário", completo: false },
    { id: 11, titulo: "Testar funcionalidades", completo: false },
    { id: 12, titulo: "Criar animações para interações", completo: false },
    { id: 13, titulo: "Implementar um tema escuro", completo: false },
    { id: 14, titulo: "Adicionar notificações de tarefas pendentes", completo: false },
    { id: 15, titulo: "Criar sistema de categorias", completo: false },
    { id: 16, titulo: "Permitir edição de tarefas", completo: false },
    { id: 17, titulo: "Sincronizar dados com backend", completo: false },
    { id: 18, titulo: "Publicar o projeto online", completo: false },
    { id: 19, titulo: "Criar documentação do projeto", completo: false },
    { id: 20, titulo: "Compartilhar o projeto com a comunidade", completo: false }
];

// console.log(data);
